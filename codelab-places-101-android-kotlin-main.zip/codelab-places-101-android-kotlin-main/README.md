Get started with the Places SDK for Android (Kotlin) codelab
======================================

## Description
Accompanying starter and solution code for the [Get started with the Places SDK for Android (Kotlin)][codelab] codelab.

## Support
If you find a bug, please [file an issue]. Or, if you'd like to contribute, send us a [pull request] and refer to our [code of conduct].

[codelab]: https://developers.google.com/codelabs/maps-platform/places-101-android-kotlin#0
[file an issue]: https://github.com/googlemaps/codelab-places-101-android-kotlin/issues
[pull request]:  https://github.com/googlemaps/codelab-places-101-android-kotlin/compare
[code of conduct]: CODE_OF_CONDUCT.md
